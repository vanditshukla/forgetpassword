<?php
session_start();
if($_SESSION['user']=="")
{
header('Location: login.php');	
echo $_SESSION['user'];
}


	





?>
<body background="images/green_background_2-wallpaper-1400x1050.jpg">
<a href="logout.php"></a>

<table width="200" border="1">
  <tr>
    
    <td><a href="logout.php">logout</a></td>
    
  </tr>
  <tr>
    
    <td>Welcome to admin area</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>