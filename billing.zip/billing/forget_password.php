<?php include('connection.php');
session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="css/font-icons.css" type="text/css" />


<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
</head>
<body>
<form name="frmForgot" id="frmForgot" method="post" onSubmit="return validate_forgot();">
<h1>Forgot Password?</h1>
  <?php if(!empty($success_message)) { ?>
  <div class="success_message"><?php echo $success_message; ?></div>
  <?php } ?>

  <div id="validation-message">
    <?php if(!empty($error_message)) { ?>
  <?php echo $error_message; ?>
  <?php } ?>
  </div>

  
  
  <div class="field-group">
    <div><label for="email">Email</label></div>
    <div><input type="text" name="member_email" id="user-email" class="input-field" required></div>
  </div>
  
  <div class="field-group">
    <div><input type="submit" name="forgot_password" id="forgot-password" value="Submit" class="form-submit-button" ></div>
  </div>  
</form>
<?php
  if(!empty($_POST["forgot_password"])){
    
    $condition = "";
    if(!empty($_POST["user_email"])) {
      $condition = " member_email = '" . $_POST["member_email"] . "'";
    }
    
    if(!empty($condition)) {
      $condition = " where " . $condition;
    }

    $sql = "Select * from members " . $condition;

    $result = mysqli_query($con,$sql);
    $user = mysqli_fetch_array($result);
    
    if(!empty($user)) {
      $random_key   = md5(uniqid(rand(), true));
      $conn_check   = mysqli_query($con, "SELECT * FROM members WHERE email='". $_POST["member_email"] ."'");
      $fetch        = mysqli_query($con, "UPDATE members SET active_code = '$random_key' WHERE member_email='". $_POST["member_email"] ."'");
      
      require_once("forgot-password-recovery-mail.php");
    } else {
      $error_message = 'No User Found';
    }
    
  }
  
?>

  
</body>
 <script src="js/bootstrap.min.js"></script>
 <script type="js/npm.js"></script>
</html>