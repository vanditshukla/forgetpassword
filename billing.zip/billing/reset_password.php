<?php 
    
    require('connection.php');
    if (isset($_POST['reset_password'])) 
    {
    	//
    	$member_email=$_GET['email'];
    	$new_password=$_POST['member_password'];
        $query = "SELECT * FROM members WHERE member_email = '$member_email'";
        $result = mysqli_query($con,$query);
        $count = mysqli_num_rows($result);

        if ($count == 1) {
            mysqli_query($con,"update members set member_password='$new_password' where member_email='$member_email'");
            //That Mail code should be put here    <----------------------
        } 
        ?>
        	<div class="alert alert-success" role="alert">Password Reset Successfully</div>
        <?php
    }
?>
<link href="demo-style.css" rel="stylesheet" type="text/css">

<form name="frmReset" id="frmReset" method="post" onSubmit="return validate_password_reset();">
<h1>Reset Password</h1>
	<?php if(!empty($success_message)) { ?>
	<div class="success_message"><?php echo $success_message; ?></div>
	<?php } ?>

	<div id="validation-message">
		<?php if(!empty($error_message)) { ?>
	<?php echo $error_message; ?>
	<?php } ?>
	</div>

	<div class="field-group">
		<div><label for="Password">Password</label></div>
		<div>
		<input type="password" name="member_password" id="member_password" class="input-field"></div>
	</div>
	
	<div class="field-group">
		<div><label for="email">Confirm Password</label></div>
		<div><input type="password" name="confirm_password" id="confirm_password" class="input-field"></div>
	</div>
	
	<div class="field-group">
		<div><input type="submit" name="reset_password" id="reset-password" value="Reset Password" class="form-submit-button"></div>
	</div>	
</form>
				