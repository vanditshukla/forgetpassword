<?php include('connection.php');
session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" href="css/font-icons.css" type="text/css" />


<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
</head>
<body>
<?php
/*
  $_POST[''] is used to get the varaible post from the form.
  isset() is use to check whether the varialbe is set or not
  Param1 : varaibale to check
*/
if(isset($_POST['save'])) {
    $login = $_POST['login'];
    $password = $_POST['password'];
    

    //this is a simple query for inserting products
     $add_query = "select * from logintest where login='".$login."' AND password='".$password."'";
    
    /*
      mysqli_query() is use to run the query
      Param1 : connection varialbe.
      Param2 : Query created above.
    */
    $result = mysqli_query($con, $add_query);
    
     $rows = mysqli_num_rows($result);
     

    if($result & $rows==1)
    
     {
        $_SESSION['user']=$login;
        header('Location: index.php');
    } else {
        header('Location: login.php?res=danger&msg=Invalid User Name Or Password');
    }
}
?>  
<?php
/*
  $_REQUEST[''] is used to get the varaible passed in the URL.
  isset() is use to check whether the varialbe is set or not
  Param1 : varaibale to check
*/

if(isset($_REQUEST['res']) && isset($_REQUEST['msg'])) { ?>
  <div class="alert alert-<?php echo $_REQUEST['res']; ?>" role="alert">
    <?php echo $_REQUEST['msg']; ?>
  </div>
<?php } ?>  

<form class="form-horizontal" method="post">
<div class="container" >
    <div class="row">
        <div class="col-md-offset-5 col-md-3">
            <div class="form-login">
            <center><img src="images/logo.png"></center>
            <h4>Welcome to Billing.</h4>
            <input type="text" for="login" id="login" name="login" class="form-control input-sm chat-input" placeholder="username" />
            </br>
            <input type="password" for="password" id="password" name="password" class="form-control input-sm chat-input" placeholder="password" />
            </br>
            <div class="wrapper">
            <span class="group-btn">     
                 <button for="save" id="login" name="save" class="btn btn-success" type="submit">login</button>
                 <a href="forget_password.php" button for="save" id="login" name="save" class="btn btn-success" type="submit">Forget Password</button></a>

            </span>
            </div>

            </div>
        
        </div>
    </div>
</div>
</form>
</body>
 <script src="js/bootstrap.min.js"></script>
 <script type="js/npm.js"></script>
</html>