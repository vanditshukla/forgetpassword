<?php


$con = mysqli_connect("localhost", "root", 'dwss123', "login") or die("Error in Connection");