<?php
define("PROJECT_HOME","http://localhost/billing/");

define("PORT", "465"); // port number
define("MAIL_USERNAME", "vanditshukla3@gmail.com"); // smtp usernmae
define("MAIL_PASSWORD", "jskvens@44"); // smtp password
define("MAIL_HOST", "smtp.gmail.com"); // smtp host
define("MAILER", "smtp");

define("SENDER_NAME", "Admin");
define("SERDER_EMAIL", "vanditshukla3@gmail.com");
?>